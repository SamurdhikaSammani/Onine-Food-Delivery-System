<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>DineDirect</title>

   <link rel="icon" href="images/logo.jpeg" type="image/x-icon">

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <style>
      .box-container {
         display: flex;
         justify-content: space-between;
      }

      .box {
         position: relative;
         overflow: hidden;
         transition: background-color 0.3s ease;
      }

      .box:hover {
         background-color: #your_hover_color; /* Change this to the desired hover color */
      }
   </style>

</head>


<body>

<?php include 'components/user_header.php'; ?>



<section class="hero">


      

         <div class="swiper-slide slide">
            <div class="content">
               <span>Food Delivery</span>
               <h3>DineDirect</h3>
               <h2>To Your Door Step</h2>
             
            </div>
            <div class="image">
                <img src="images/img-01.avif" alt="">
            </div>
         </div>

</section>

<section class="category" style="position: relative; background-image: url('images/food-1024x683.jpg'); background-size: cover; background-position: center;">

   <!-- Pseudo-element for white mist and blur effect -->
   <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255, 255, 255, 0.5); filter: blur(10px);"></div>

   <h1 class="title" style="color: white;">food category</h1>

   <div class="box-container">

      <a href="category.php?category=fast food" class="box" style="background-color: #your_default_color;">
         <img src="images/cat-1.png" alt="">
         <h3>fast food</h3>
      </a>

      <a href="category.php?category=main dish" class="box" style="background-color: #your_default_color;">
         <img src="images/cat-2.png" alt="">
         <h3>main dishes</h3>
      </a>

      <a href="category.php?category=drinks" class="box" style="background-color: #your_default_color;">
         <img src="images/cat-3.png" alt="">
         <h3>drinks</h3>
      </a>

      <a href="category.php?category=desserts" class="box" style="background-color: #your_default_color;">
         <img src="images/cat-4.png" alt="">
         <h3>desserts</h3>
      </a>

   </div>

</section>



    <br><br><br><br><br>

<?php include 'components/footer.php'; ?>




<!-- custom js file link  -->
<script src="js/script.js"></script>


</body>
</html>